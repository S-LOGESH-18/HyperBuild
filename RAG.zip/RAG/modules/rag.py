from sentence_transformers import SentenceTransformer
import numpy as np
import faiss
import subprocess
from .docs import docs

embed_model = SentenceTransformer('all-MiniLM-L6-v2')
doc_embeddings = embed_model.encode(docs)
index = faiss.IndexFlatL2(doc_embeddings[0].shape[0])
index.add(np.array(doc_embeddings))

def get_rag_context(query):
    query_embedding = embed_model.encode([query])
    _, I = index.search(np.array(query_embedding), k=3)
    return "\n".join([docs[i] for i in I[0]])

def get_rag_answer(prompt):
    result = subprocess.run(
        ["ollama", "run", "llama3"],
        input=prompt,
        text=True,
        capture_output=True,
        encoding='utf-8'
    )
    return result.stdout.strip()
