import os
import json

def load_user_data(json_path="db.json"):
    if not os.path.exists(json_path):
        return {}
    with open(json_path, "r") as f:
        return json.load(f)

def get_user_specific_answer(query, user_data):
    for key, value in user_data.items():
        if key.replace("_", " ") in query.lower():
            return f"🔍 From your saved data, {key.replace('_', ' ').capitalize()}: {value}"
        elif any(word in query.lower() for word in key.split("_")):
            return f"🔍 Based on your data, {key.replace('_', ' ').capitalize()}: {value}"
    return None
