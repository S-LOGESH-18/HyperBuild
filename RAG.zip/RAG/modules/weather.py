import requests

WEATHER_API_KEY = "b7a7000727764a229a840117250408"
WEATHER_API_URL = "http://api.weatherapi.com/v1/current.json"

def get_weather(city):
    try:
        response = requests.get(WEATHER_API_URL, params={
            "key": WEATHER_API_KEY,
            "q": city
        })
        data = response.json()
        if "error" in data:
            return f"⚠️ Could not fetch weather: {data['error']['message']}"
        condition = data["current"]["condition"]["text"]
        temp_c = data["current"]["temp_c"]
        feels_like = data["current"]["feelslike_c"]
        return f"🌤️ Weather in {city}: {condition}, {temp_c}°C (feels like {feels_like}°C)"
    except Exception as e:
        return f"❌ Error fetching weather: {str(e)}"

weather_keywords = ["weather", "temperature", "forecast", "climate"]
def is_weather_query(q):
    return any(kw in q.lower() for kw in weather_keywords)
