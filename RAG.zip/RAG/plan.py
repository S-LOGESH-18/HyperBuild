from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import requests
from io import BytesIO
import os
from flask import send_file
from datetime import datetime
from RagMain import get_rag_answer,get_rag_context
app = Flask(__name__)
CORS(app)
STABILITY_API_KEY = "sk-cCWDG0VEFj2KaWtpf6lvztbPYyXJJPgTUf3DkJq6RsFA862W"
# STABILITY_API_URL_2D = "https://api.stability.ai/v2beta/stable-image/generate/sd3"
# STABILITY_API_URL_2D = "https://api.stability.ai/v2beta/stable-image/generate/ultra"
STABILITY_API_URL_2D = "https://api.stability.ai/v2beta/stable-image/generate/core"

STABILITY_API_URL_3D=0
def build_villa_prompt(data):
    features = []
    if data.get('building_lift') == 'Yes':
        features.append("a lift")
    if data.get('building_penthouse') == 'Yes':
        features.append("a penthouse on the top floor")
    if data.get('building_play_area') == 'Yes':
        features.append("a play area")
    if data.get('building_basement') == 'Yes':
        features.append("a basement")
    if data.get('building_sump') == 'Yes':
        features.append("a sump")
    if data.get('building_generator') and isinstance(data['building_generator'], str):
        features.append(f"a {data['building_generator'].lower()} generator")
    if data.get('building_water_storage') and isinstance(data['building_water_storage'], str):
        features.append(f"an overhead {data['building_water_storage'].lower()} for water storage")

    feature_text = ", ".join(features)
    return (
        f"Generate a clean, high-resolution (1024x1024) black and white 2D architectural floor plan for a modern villa. "
        f"The villa should be built on a {data['dimension']} feet plot and must strictly fit within this size. "
        f"The plan should have {data['villa_floors']} floor(s), including {data['villa_bedrooms']} bedroom(s), parking for {data['villa_parking']} vehicle(s)"
        f"{feature_text}."
    )

#     return (
#     f"Generate a clean, high-resolution (1024x1024) black and white 2D architectural floor plan for a modern villa. "
#     f"The villa should be built on a {data['dimension']} feet plot and must strictly fit within this size. "
#     f"The plan should have {data['villa_floors']} floor(s), including {data['villa_bedrooms']} bedroom(s), parking for {data['villa_parking']} vehicle(s)"
#     f"{', ' + feature_text if feature_text else ''}. "
#     f"Ensure the layout is like a professional house blueprint, similar to 2Dhouses-style drawings. "
#     f"Display a clear layout with all rooms, walls (solid black lines), doors, windows, stairs, and parking. "
#     f"Include labeled furniture in each room (e.g., beds, sofas, wardrobes, tables) for clarity. "
#     f"All rooms must be labeled in **English** (e.g., Bedroom, Kitchen, Hall, Dining, Toilet, Porch, Wash Area) "
#     f"and each room must clearly display its dimensions in feet (e.g., 12'0\"x14'0\"). "
#     f"Maintain logical and functional room placement, with good ventilation and access. "
#     f"Use strong black lines for all walls, a white background, and ensure high contrast and sharpness. "
#     f"The final image must be detailed, readable, and suitable for architectural and construction planning."
# )


def build_building_prompt(data):
    return (
        f"Generate a clear, black and white 2D floor plan for a residential building with {data['building_floors']} floors and {data['building_units']} unit(s) per floor. "
        f"Each unit should have {data['building_bedrooms']} bedroom(s). "
        f"{'Include a lift, ' if data['building_lift'] == 'Yes' else ''}"
        f"{'a penthouse on the top floor, ' if data['building_penthouse'] == 'Yes' else ''}"
        f"{'a play area, ' if data['building_play_area'] == 'Yes' else ''}"
        f"{'a basement, ' if data['building_basement'] == 'Yes' else ''}"
        f"parking space for {data['building_parking']} vehicle(s), "
        f"{'a sump, ' if data['building_sump'] == 'Yes' else ''}"
        f"{'a ' + data.get('building_generator', '').lower() + ' generator, ' if 'building_generator' in data else ''}"
        f"{'an overhead ' + data.get('building_water_storage', '').lower() + ' for water storage. ' if 'building_water_storage' in data else ''}"
        f"Ensure logical unit layout, vertical circulation via stairs and lift, and utility space allocation on each floor. "
        f"Label all units and rooms clearly in English and mention approximate sizes. "
        f"The plan should be in black and white with clean walls, labeled rooms, stairs, and lift access across floors. "
        f"Differentiate unit boundaries and utility areas like toilets, balconies, and stairs visually using solid or dashed lines. "
        f"Ensure the circulation design is practical for multi-floor vertical movement."
    )


@app.route('/generate-plan', methods=['POST'])

def generate_plan():
    data = request.get_json()

    if not data:
        return jsonify({"error": "Missing JSON payload"}), 400

    if "dimension" in data and "villa_floors" in data:
        prompt = build_villa_prompt(data)
    elif "building_floors" in data and "building_units" in data:
        prompt = build_building_prompt(data)
    else:
        return jsonify({"error": "Unrecognized or incomplete data"}), 400

    response = requests.post(
        STABILITY_API_URL_2D,
        headers={
            "authorization": f"{STABILITY_API_KEY}",
            "accept": "image/*"
        },
        files={"none": ''},
        data={
            "prompt": prompt,
            "output_format": "jpeg"
        }
    )

    if response.status_code == 200:
        image_stream = BytesIO(response.content)
        image_stream.seek(0)
        image_data = response.content

        # ✅ Save the image to local directory
        os.makedirs("output", exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"villa_plan_{timestamp}.jpeg"
        filepath = os.path.join("output", filename)
        with open(filepath, "wb") as f:
            f.write(image_data)
        return send_file(image_stream, mimetype='image/jpeg')
    else:
        try:
            return jsonify({"error": response.json()}), response.status_code
        except:
            return jsonify({"error": "Failed to parse error response"}), response.status_code

@app.route('/generate-glb', methods=['POST'])
def generate_glb():
    try:
        data = request.get_json()
        # Process and generate .glb file
        return send_file("output.glb", as_attachment=True)
    except Exception as e:
        print("Error generating GLB:", e)
        return jsonify({"error": str(e)}), 500
@app.route('/generate-3d-plan', methods=['POST'])
def generate_3d_plan():
    """
    Expects a multipart form with an image file.
    """
    if 'image' not in request.files:
        return jsonify({"error": "Image file missing"}), 400

    image_file = request.files['image']

    response = requests.post(
        STABILITY_API_URL_3D,
        headers={
            "authorization": f"Bearer {STABILITY_API_KEY}",
        },
        files={
            "image": image_file.read()
        }
    )

    if response.status_code == 200:
        model_stream = BytesIO(response.content)
        model_stream.seek(0)
        return send_file(model_stream, mimetype='model/gltf-binary', as_attachment=True, download_name='3d-plan.glb')
    else:
        try:
            return jsonify({"error": response.json()}), response.status_code
        except:
            return jsonify({"error": "Failed to parse 3D generation error"}), response.status_code

if __name__ == '__main__':
    app.run(debug=True)
