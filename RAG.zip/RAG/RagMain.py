# app.py
from flask import Flask, request, jsonify
from flask_cors import CORS
from modules.user_data import load_user_data, get_user_specific_answer
from modules.weather import get_weather, is_weather_query
from modules.rag import get_rag_context, get_rag_answer

app = Flask(__name__)
CORS(app)
user_data = load_user_data()

@app.route("/ask", methods=["POST"])
def ask_question():
    query = request.json.get("query", "").strip()
    if not query:
        return jsonify({"error": "No query provided"}), 400

    if query.lower() in ['exit', 'quit']:
        return jsonify({"response": "👋 Exiting RAG system."})

    user_answer = get_user_specific_answer(query, user_data)
    if user_answer:
        return jsonify({"response": user_answer})

    if "plan" in query.lower() or "villa" in query.lower():
        plan = user_data.get("plan") or user_data.get("villa_plan") or "📂 No villa plan found in your saved data."
        return jsonify({"response": f"📐 Your villa plan:\n{plan}"})

    if "estimate" in query.lower() or "cost" in query.lower():
        area = user_data.get("built_up_area")
        if not area:
            return jsonify({"response": "📏 Built-up area not found in saved data. Cannot estimate cost."})
        try:
            area = float(area)
            min_cost = area * 1500
            max_cost = area * 2000
            return jsonify({"response": f"💸 Estimated cost for {area} sq.ft: ₹{min_cost:,.0f} to ₹{max_cost:,.0f}"})
        except:
            return jsonify({"response": "⚠️ Error reading built-up area from data."})

    if "status" in query.lower() or "construction" in query.lower():
        city = user_data.get("city") or request.json.get("city")
        if not city:
            return jsonify({"error": "City not provided"}), 400
        
        weather = get_weather(city)
        advice = ""
        if any(x in weather.lower() for x in ["sunny", "clear", "partly cloudy", "dry"]):
            advice = "📅 Today is suitable for exterior work like walls or basement construction."
        elif any(x in weather.lower() for x in ["rain", "rainny", "drizzle", "storm"]):
            advice = "🌧️ Due to rain, exterior construction is postponed. Interior work will continue."
        else:
            advice = "⚠️ Weather unclear. Please confirm with the on-site supervisor."

        return jsonify({"response": f"{weather}\n\n{advice}"})

    if is_weather_query(query):
        city = None
        words = query.split()
        for i in range(len(words) - 1):
            if words[i].lower() in ["in", "at", "for"]:
                city = words[i + 1].capitalize()
                break
        if not city:
            return jsonify({"error": "City not found in query"}), 400

        return jsonify({"response": get_weather(city)})


    context = get_rag_context(query)
    prompt = f"""You are a house planning assistant. Answer questions using the following context:

Context:
{context}

Question: {query}
Answer:"""

    answer = get_rag_answer(prompt)
    return jsonify({"response": answer})


if __name__ == "__main__":
    app.run(debug=True,port =3000)
