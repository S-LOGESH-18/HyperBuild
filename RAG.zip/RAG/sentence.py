from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import subprocess
import requests
import json
import os
##
def load_user_data(json_path="db.json"):
    if not os.path.exists(json_path):
        return {}
    with open(json_path, "r") as f:
        return json.load(f)
##
def get_user_specific_answer(query, user_data):
    for key, value in user_data.items():
        if key.replace("_", " ") in query.lower():
            return f"🔍 From your saved data, {key.replace('_', ' ').capitalize()}: {value}"
        elif any(word in query.lower() for word in key.split("_")):
            return f"🔍 Based on your data, {key.replace('_', ' ').capitalize()}: {value}"
    return None

WEATHER_API_KEY = "b7a7000727764a229a840117250408" 
WEATHER_API_URL = "http://api.weatherapi.com/v1/current.json"

def get_weather(city):
    try:
        response = requests.get(WEATHER_API_URL, params={
            "key": WEATHER_API_KEY,
            "q": city
        })
        data = response.json()
        if "error" in data:
            return f"⚠️ Could not fetch weather: {data['error']['message']}"
        condition = data["current"]["condition"]["text"]
        temp_c = data["current"]["temp_c"]
        feels_like = data["current"]["feelslike_c"]
        return f"🌤️ Weather in {city}: {condition}, {temp_c}°C (feels like {feels_like}°C)"
    except Exception as e:
        return f"❌ Error fetching weather: {str(e)}"

docs = [
    "A 30x40 site typically accommodates a 2BHK house with living room, kitchen, dining, bathroom, and a small utility or pooja room.",
    "The standard cost of construction in India varies between ₹1,500 to ₹2,000 per square foot for regular finish and ₹2,200 to ₹2,800 for premium finish.",
    "The built-up area is calculated by multiplying the total floor area by the number of floors, including balconies and stairs.",
    "Vastu recommends the entrance of the house to be in the northeast or east direction for positive energy.",
    "The master bedroom should ideally be placed in the southwest corner of the house.",
    "The kitchen is best placed in the southeast corner and should never be directly in front of the main door.",
    "Bathrooms should be in the west or northwest corner of the house as per Vastu.",
    "A pooja room should be located in the northeast direction with idols facing east or west.",
    "Staircases should always rotate clockwise and be in the south or west direction.",
    "For a 2BHK ground floor home of 900 sq.ft, the construction cost would be approximately ₹13.5 to ₹18 lakhs at ₹1,500–2,000 per sq.ft.",
    "Compound walls should be higher on the south and west sides compared to the north and east sides.",
    "In a 3BHK house, one bedroom is usually placed on the ground floor for elder access, while two are on the first floor.",
    "Placing car parking in the northeast corner (for east-facing plots) leaves good open space and Vastu compliance.",
    "The site should ideally slope towards the northeast for good drainage and energy flow.",
    "North- and east-facing plots are considered more auspicious for residential buildings.",
    "A borewell or water sump should be constructed in the northeast corner of the plot.",
    "The septic tank should be placed in the northwest or southeast zone, but never in the northeast.",
    "A portico or sit-out area is commonly placed in the northeast or east side to maximize morning light.",
    "Windows should be larger on the north and east sides for ventilation and natural lighting.",
    "The center of the house (Brahmasthan) should ideally be left open or used minimally.",
    "In duplex homes, keep the living space on the ground floor and bedrooms upstairs for better privacy.",
    "A rectangular or square site is ideal as per Vastu; avoid irregular plot shapes.",
    "Always consult a structural engineer when building more than two floors to ensure safety and code compliance."
]
##
embed_model = SentenceTransformer('all-MiniLM-L6-v2')
doc_embeddings = embed_model.encode(docs)
index = faiss.IndexFlatL2(doc_embeddings[0].shape[0])
index.add(np.array(doc_embeddings))

weather_keywords = ["weather", "temperature", "forecast", "climate"]
def is_weather_query(q):
    return any(kw in q.lower() for kw in weather_keywords)

user_data = load_user_data()

while True:
    query = input("\n💬 Ask your question (or type 'exit' to quit): ").strip()
    if query.lower() in ['exit', 'quit']:
        print("👋 Exiting RAG system.")
        break

    user_answer = get_user_specific_answer(query, user_data)
    if user_answer:
        print(user_answer)
        continue
        # 💡 Handle "plan" or "villa" related queries from db.json
    if "plan" in query.lower() or "villa" in query.lower():
        plan = user_data.get("plan") or user_data.get("villa_plan") or "📂 No villa plan found in your saved data."
        print(f"📐 Your villa plan:\n{plan}")
        continue

    # 💰 Estimate cost using built-up area from db.json
    if "estimate" in query.lower() or "cost" in query.lower():
        area = user_data.get("built_up_area")
        if not area:
            print("📏 Built-up area not found in saved data. Cannot estimate cost.")
            continue
        try:
            area = float(area)
            min_cost = area * 1500
            max_cost = area * 2000
            print(f"💸 Estimated cost for {area} sq.ft: ₹{min_cost:,.0f} to ₹{max_cost:,.0f}")
        except:
            print("⚠️ Error reading built-up area from data.")
        continue

    # 🏗️ Construction status check based on weather
    if "status" in query.lower() or "construction" in query.lower():
        city = user_data.get("city") or input("🌆 Enter city to check weather-based status: ")
        weather = get_weather(city)
        print(weather)

        if any(x in weather.lower() for x in ["sunny", "clear", "partly cloudy", "dry"]):
            print("📅 Today is suitable for exterior work like walls or basement construction.")
        elif any(x in weather.lower() for x in ["rain","rainny","drizzle", "storm"]):
            print("🌧️ Due to rain, exterior construction is postponed. Interior work will continue.")
        else:
            print("⚠️ Weather unclear. Please confirm with the on-site supervisor.")
        continue


    if is_weather_query(query):
        city = None
        words = query.split()
        for i in range(len(words) - 1):
            if words[i].lower() in ["in", "at", "for"]:
                city = words[i + 1].capitalize()
                break
        if not city:
            city = input("🌍 Please enter the city name: ").strip().capitalize()
        print("\n🔎 Fetching real-time weather...\n")
        print(get_weather(city))
        continue

    query_embedding = embed_model.encode([query])
    _, I = index.search(np.array(query_embedding), k=3)
    context = "\n".join([docs[i] for i in I[0]])

    rag_prompt = f"""You are a house planning assistant. Answer questions using the following context:

Context:
{context}

Question: {query}
Answer:"""

    print("\n🤖 LLaMA 3 is thinking...\n")

    # ✅ Use Ollama (LLaMA 3)
    result = subprocess.run(
        ["ollama", "run", "llama3"],
        input=rag_prompt,
        text=True,
        capture_output=True,
        encoding='utf-8'
    )

    print("🧠 RAG Answer:\n", result.stdout.strip())
