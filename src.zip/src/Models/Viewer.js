import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Html } from '@react-three/drei';
import Scene from './Villa'; // Make sure this component handles glbUrl

const Viewer = () => {
  const glbUrl = localStorage.getItem("glbUrl");

  if (!glbUrl) {
    return (
      <div style={{ padding: '40px', textAlign: 'center', fontFamily: 'sans-serif' }}>
        <h2>❌ No 3D model found</h2>
        <p>Please generate a 3D model before accessing this page.</p>
      </div>
    );
  }

  return (
    <div style={{ height: '100vh', width: '100vw' }}>
      <Canvas shadows camera={{ position: [5, 5, 10], fov: 45 }}>
        <color attach="background" args={['#f0f0f0']} />
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 10]} intensity={1} castShadow />
        <Suspense fallback={<Html><div style={{ color: "#333" }}>⏳ Loading model...</div></Html>}>
          <Scene glbUrl={glbUrl} />
        </Suspense>
        <OrbitControls />
      </Canvas>
    </div>
  );
};

export default Viewer;
