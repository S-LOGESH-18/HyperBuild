import React, { Suspense, useEffect } from 'react';
import { OrbitControls, Environment, ContactShadows } from '@react-three/drei';
import Model from './Model';
import { useGLTF } from '@react-three/drei';

const Scene = ({ glbUrl }) => {
  useEffect(() => {
    if (glbUrl) {
      useGLTF.preload(glbUrl);
    }
  }, [glbUrl]);

  return (
    <>
      <ambientLight intensity={0.6} />
      <directionalLight
        position={[10, 20, 10]}
        intensity={1}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
      />
      <Suspense fallback={null}>
        {glbUrl && <Model path={"D:/CompanyProject/planner/public/modern_luxury_villa_house_building.glb"} position={[0, 0, 0]} scale={1.5} />}
      </Suspense>
      <ContactShadows
        position={[0, -0.01, 0]}
        opacity={0.4}
        scale={50}
        blur={1}
        far={10}
      />
      <Environment preset="sunset" />
      <OrbitControls enablePan enableZoom enableRotate />
    </>
  );
};

export default Scene;