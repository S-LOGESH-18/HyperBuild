import React, { useState, useRef, useEffect } from "react";
import "./Chatbot.css";
import { FaRobot, FaUserCircle } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';
import axios from "axios";

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const villaImageURL = "https://1.bp.blogspot.com/-bL7qzz8zDZY/WiaH1cmq7HI/AAAAAAAAA9k/XG7-UjRpIfIH4oivUwnMeMG_dThoTwr3ACEwYBhgL/s1600/karuka.jpg";
const buildingImageURL = "https://7dplans.com/wp-content/uploads/2023/01/FRONT.jpg";


const villaQuestions = [
  { text: "How many floors do you want?", options: ["1", "2", "3"], key: "villa_floors" },
  { text: "Do you need a lift?", options: ["Yes", "No"], key: "villa_lift" },
  { text: "How many bedrooms?", options: ["2", "3", "4", "5+"], key: "villa_bedrooms" },
  { text: "Do you need a puja room?", options: ["Yes", "No"], key: "villa_puja" },
  { text: "Do you need a media room?", options: ["Yes", "No"], key: "villa_media" },
  { text: "Do you need a gym?", options: ["Yes", "No"], key: "villa_gym" },
  { text: "Kids play area?", options: ["Yes", "No"], key: "villa_play_area" },
  { text: "Need a basement?", options: ["Yes", "No"], key: "villa_basement" },
  { text: "Car parking - how many cars?", options: ["1", "2", "3+"], key: "villa_parking" },
  { text: "Do you need a sump?", options: ["Yes", "No"], key: "villa_sump" },
  { text: "Do you need a generator?", options: ["No", "Yes - Front", "Yes - Back"], key: "villa_generator" },
  { text: "Water storage: Tank on top or Pressure pump?", options: ["Water tank", "Pressure pump"], key: "villa_water_storage" }
];

const buildingQuestions = [
  { text: "How many floors?", options: ["2", "3", "4+"], key: "building_floors" },
  { text: "How many houses per floor?", options: ["1", "2", "3+"], key: "building_units" },
  { text: "Bedrooms per house?", options: ["1", "2", "3", "4+"], key: "building_bedrooms" },
  { text: "Do you need a lift?", options: ["Yes", "No"], key: "building_lift" },
  { text: "Do you want a penthouse?", options: ["Yes", "No"], key: "building_penthouse" },
  { text: "Kids play area?", options: ["Yes", "No"], key: "building_play_area" },
  { text: "Need a basement?", options: ["Yes", "No"], key: "building_basement" },
  { text: "Car parking - how many cars?", options: ["1", "2", "3+"], key: "building_parking" },
  { text: "Do you need a sump?", options: ["Yes", "No"], key: "building_sump" },
  { text: "Do you need a generator?", options: ["No", "Yes - Front", "Yes - Back"], key: "building_generator" },
  { text: "Water storage: Tank on top or Pressure pump?", options: ["Water tank", "Pressure pump"], key: "building_water_storage" }
];
const Chatbot = () => {
  const [messages, setMessages] = useState([]);
  const [showGenerate2D, setShowGenerate2D] = useState(false);
  const [showGenerate3D, setShowGenerate3D] = useState(false);
  const [stage, setStage] = useState("init");
  const [userName, setUserName] = useState("");
  const [verificationMethod, setVerificationMethod] = useState("");
  const [userInput, setUserInput] = useState("");
  const [propertyType, setPropertyType] = useState("");
  const [questionSet, setQuestionSet] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const messagesEndRef = useRef(null);
  const [answers, setAnswers] = useState({});
  const [showOptions, setShowOptions] = useState(false);
  const chatEndRef = useRef(null);
  const nextId = useRef(1);
  const initialized = useRef(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const [imageBlob2D, setImageBlob2D] = useState(null);
  const [customInputActiveIndex, setCustomInputActiveIndex] = useState(null);
  const [customAnswer, setCustomAnswer] = useState("");

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);


  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    botTypingThenSend("Hi! I'm your Planner Assistant.", () => {
      botTypingThenSend("What's your name?");
      setStage("askName");
    });
  }, []);

  useEffect(() => {
    if (chatEndRef.current) chatEndRef.current.scrollIntoView({ behavior: "smooth" });
  }, [messages, showOptions]);

  const botTypingThenSend = (text, callback) => {
    const typingId = nextId.current++;
    setMessages(prev => [...prev, { id: typingId, type: "bot", text: "..." }]);

    setTimeout(() => {
      setMessages(prev =>
        [...prev.filter(msg => msg.id !== typingId), { id: nextId.current++, type: "bot", text }]
      );
      if (callback) callback();
    }, 1000);
  };

  const addUser = (text) => {
    setMessages(prev => [...prev, { id: nextId.current++, type: "user", text }]);
  };

  const handleUserInput = (e) => setUserInput(e.target.value);

  const handleSubmit = (e) => {
    e.preventDefault();
    const txt = userInput.trim();
    if (!txt) return;

    addUser(txt);
    setUserInput("");

    if (stage === "askName") {
      setUserName(txt);
      setAnswers(prev => ({ ...prev, user_name: txt }));
      botTypingThenSend(`Nice to meet you, ${txt}!`, () => {
        botTypingThenSend("Would you like to verify using Phone or Email?");
        setStage("askMethod");
      });

    } else if (stage === "phone") {
      if (/^[6-9]\d{9}$/.test(txt)) {
        setAnswers(prev => ({ ...prev, phone: txt }));
        botTypingThenSend("📲 Enter OTP...");
        setStage("otp");
      } else {
        botTypingThenSend("❌ Invalid phone number. Please enter again.");
      }

    } else if (stage === "email") {
      if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(txt)) {
        setAnswers(prev => ({ ...prev, email: txt }));
        botTypingThenSend("📧 Enter OTP ...");
        setStage("otp");
      } else {
        botTypingThenSend("❌ Invalid email address.");
      }

    } else if (stage === "otp") {
      if (txt === "1234") {
        botTypingThenSend(`${verificationMethod === "phone" ? "Phone" : "Email"} verified ✅`, () => {
          botTypingThenSend("Let's start planning your house.", () => {
            botTypingThenSend("Do you already have a property?", () => {
              setStage("hasProperty");
            });
          });
        });
      } else {
        botTypingThenSend("❌ Incorrect OTP. Please try again (hint: 1234)");
      }

    } else if (stage === "propertyPlanToBuy") {
      setAnswers(prev => ({ ...prev, planning_to_buy: txt }));
      botTypingThenSend("Great, we'll keep that in mind.");
      setTimeout(() => {
        botTypingThenSend("Here are some options to choose from:");
        setStage("choosePropertyType");
      }, 1000);
    }
  };

  const handleMethod = (method) => {
    addUser(method);
    setVerificationMethod(method.toLowerCase());
    setAnswers(prev => ({ ...prev, verification_method: method }));
    if (method === "Phone") {
      botTypingThenSend("📱 Please enter your 10-digit mobile number:");
      setStage("phone");
    } else {
      botTypingThenSend("📧 Please enter your email address:");
      setStage("email");
    }
  };
  const saveToServer = async (data, type) => {
    try {
      const response = await fetch(`http://localhost:3001/${type}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to save data");
      console.log("✅ Data saved to JSON Server!");
    } catch (error) {
      console.error("❌ Error saving data:", error);
    }
  };

  const askNextDynamicQuestion = (index, list) => {
    setCurrentQuestionIndex(index);
    setShowOptions(false);
    botTypingThenSend(list[index].text, () => {
      setShowOptions(true);
    });
  };

  const handlePropertyType = (type) => {
    addUser(type);
    setPropertyType(type);
    const selected = type === "Villa" ? villaQuestions : buildingQuestions;
    setQuestionSet(selected);
    askNextDynamicQuestion(0, selected);
    setStage("planning");
  };

  const [villaData, setVillaData] = useState([]);
  const [buildingData, setBuildingData] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3001/villa").then((res) => setVillaData(res.data));
    axios.get("http://localhost:3001/building").then((res) => setBuildingData(res.data));
  }, []);

  const handleGenerate2D = async () => {
    const url = "http://127.0.0.1:5000/generate-plan";
    const payload = {
      id: Date.now(),
      ...answers,
      dimension: answers.dimension || "60 x 40",
    };

    try {
      setLoading(true);
      const res = await axios.post(url, payload, {
        responseType: "blob",
      });

      const imageBlob = new Blob([res.data], { type: "image/jpeg" });
      const imageURL = URL.createObjectURL(imageBlob);

      setImageBlob2D(imageBlob); // Save for 3D use
      toast.success("✅ 2D Plan is ready!");
      
      await sendToOtherServer(payload);
      botTypingThenSend(
        `<div>
        🖼️ Here's your 2D floor plan preview:<br/>
        <a href="${imageURL}" target="_blank">
        <img src="${imageURL}" alt="2D Floor Plan" style="max-width:100%; border-radius:8px; margin-top:10px; cursor:pointer;" />
        </a>
        </div>`,
        () => {
          setShowGenerate2D(false)
        }
      );

    } catch (err) {
      console.error("❌ Error generating 2D floor plan:", err);
      setShowGenerate2D(false)
      toast.error("Error!");
      botTypingThenSend("❌ Failed to generate floor plan. Please try again.");
    } finally {
      setShowGenerate2D(false)
      setLoading(false);
    }
  }

  const sendToOtherServer = async (payload) => {
    try {
      const response = await fetch("http://127.0.0.1:3000/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!response.ok) throw new Error("Failed to get response from other server");

      const data = await response.json();

      // Assuming the server returns { message: "..." }
      botTypingThenSend(data.message || "✅ Got response from server!");
    } catch (error) {
      console.error(error);
      botTypingThenSend("❌ Error connecting to the server.");
    }
  };


  return (
    <div className="chatbot-main-container">
      <ToastContainer position="top-right" autoClose={3000} />
      <div className="chatbot-left-panel-modern">
        <div className="chatbot-tab" onClick={() => navigate("/")}>
          <span role="img" aria-label="3d">🏗️</span> <span>3D Generator</span>
        </div>
        <div className="chatbot-history-title">🗂️ Summary</div>

        <ul className="chatbot-history-scroll">
          {["Villa", "Building"].map((type) => {
            const prefix = type.toLowerCase() + "_";

            const filteredEntries = Object.entries(answers).filter(
              ([key]) => key.startsWith(prefix) || key === "dimension"
            );

            if (filteredEntries.length === 0) return null;

            return (
              <div key={type} className="chatbot-history-summary-group">
                <div className="chatbot-history-group-title">🏠 {type}</div>
                <div className="chatbot-history-grid">
                  {filteredEntries.map(([key, val]) => {
                    const displayKey =
                      key === "dimension"
                        ? "Dimension"
                        : key.replace(prefix, "").replace(/_/g, " ");

                    return (
                      <div key={key} className="chatbot-history-button-container">
                        <button className="chatbot-history-button">
                          <strong>{displayKey}:</strong> {val}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </ul>
      </div>

      <div className="chatbot-right-panel">
        <div className="chatbot-header"><FaRobot className="chatbot-icon" /></div>
        <h2 className="chatbot-title">HyperBuilder</h2>

        <div className="chatbot-chat-area">
          {messages.map(m =>
            m.type === "bot" ? (
              <div key={m.id} className="chatbot-bubble-row">
                <span className="chatbot-bot-avatar"><FaRobot /></span>
                <div className="chatbot-bubble bot-bubble"><span dangerouslySetInnerHTML={{ __html: m.text }} /></div>
              </div>
            ) : (
              <div key={m.id} className="chatbot-bubble-row user-row">
                <span className="chatbot-user-avatar"><FaUserCircle /></span>
                <div className="chatbot-bubble user-bubble"><span>{m.text}</span></div>
              </div>
            )
          )}

          {stage === "askMethod" && (
            <div className="chatbot-inline-options">
              <button onClick={() => handleMethod("Phone")} className="chatbot-option-btn">Phone</button>
              <button onClick={() => handleMethod("Email")} className="chatbot-option-btn">Email</button>
            </div>
          )}

          {stage === "hasProperty" && (
            <div className="chatbot-inline-options">
              <button onClick={() => {
                addUser("Yes");
                setAnswers(prev => ({ ...prev, has_property: "Yes" }));
                botTypingThenSend("What are the property dimensions?", () => {
                  setStage("propertyDimension");
                });
              }} className="chatbot-option-btn">Yes</button>
              <button onClick={() => {
                addUser("No");
                setAnswers(prev => ({ ...prev, has_property: "No" }));
                botTypingThenSend("What kind of property are you planning to buy?");
                setStage("propertyPlanToBuy");
              }} className="chatbot-option-btn">No</button>
            </div>
          )}

          {stage === "propertyDimension" && (
            <div className="chatbot-inline-options">
              {["60 x 40", "40 x 30"].map(dim => (
                <button key={dim} className="chatbot-option-btn" onClick={() => {
                  addUser(dim);
                  setAnswers(prev => ({ ...prev, dimension: dim }));
                  botTypingThenSend("Thanks! Now, here are some options to choose from:");
                  setStage("choosePropertyType");
                }}>{dim}</button>
              ))}
            </div>
          )}

          {stage === "choosePropertyType" && (
            <div className="chatbot-inline-options">
              <div className="chatbot-option-btn" onClick={() => handlePropertyType("Villa")}>
                <img src={villaImageURL} alt="Villa" style={{ width: "100%", height: "80px", objectFit: "cover" }} />
                <div style={{ textAlign: "center" }}>Villa</div>
              </div>
              <div className="chatbot-option-btn" onClick={() => handlePropertyType("Building")}>
                <img src={buildingImageURL} alt="Building" style={{ width: "100%", height: "80px", objectFit: "cover" }} />
                <div style={{ textAlign: "center" }}>Building</div>
              </div>
            </div>
          )}

          {stage === "planning" && questionSet[currentQuestionIndex] && showOptions && (
            <div style={{ marginTop: "16px" }}>
              <div style={{
                display: "flex", flexWrap: "wrap", gap: "12px", justifyContent: "center",
              }}>
                {questionSet[currentQuestionIndex].options.map(option => (
                  <button
                    key={option}
                    className="chatbot-option-btn"
                    onClick={() => {
                      addUser(option);
                      const q = questionSet[currentQuestionIndex];
                      const updated = { ...answers, [q.key]: option };
                      setAnswers(updated);
                      setCustomInputActiveIndex(null);
                      setCustomAnswer("");

                      if (currentQuestionIndex + 1 < questionSet.length) {
                        askNextDynamicQuestion(currentQuestionIndex + 1, questionSet);
                      } else {
                        const summary = Object.entries(updated)
                          .map(([key, val]) => `<li><strong>${key.replace(/_/g, " ")}:</strong> ${val}</li>`)
                          .join("");

                        const payload = {
                          id: Date.now(),
                          userName,
                          ...updated
                        };

                        const typeKey = propertyType.toLowerCase();
                        saveToServer(payload, typeKey);

                        botTypingThenSend(
                          `<div class="chatbot-summary-box"><p>✅ <strong>Summary:</strong></p><ul>${summary}</ul></div>`,
                          () => {
                            setStage("done");
                            setShowGenerate2D(true);
                          }
                        );
                      }
                    }}
                  >
                    {option}
                  </button>
                ))}

                <button
                  className="chatbot-option-btn"
                  style={{ backgroundColor: "#444", color: "#fff", border: "1px dashed #ccc" }}
                  onClick={() => {
                    setCustomInputActiveIndex(currentQuestionIndex);
                  }}
                >
                  Custom
                </button>
              </div>

              {/* Show input box if "Custom" is clicked for current question */}
              {customInputActiveIndex === currentQuestionIndex && (
                <div style={{ marginTop: "12px", textAlign: "center" }}>
                  <input
                    type="text"
                    placeholder="Enter your custom answer"
                    value={customAnswer}
                    onChange={(e) => setCustomAnswer(e.target.value)}
                    style={{
                      padding: "10px",
                      width: "70%",
                      borderRadius: "6px",
                      border: "1px solid #ccc",
                      marginRight: "10px"
                    }}
                  />
                  <button
                    onClick={() => {
                      const trimmed = customAnswer.trim();
                      if (!trimmed) return;

                      addUser(trimmed);
                      const q = questionSet[currentQuestionIndex];
                      const updated = { ...answers, [q.key]: trimmed };
                      setAnswers(updated);
                      setCustomInputActiveIndex(null);
                      setCustomAnswer("");

                      if (currentQuestionIndex + 1 < questionSet.length) {
                        askNextDynamicQuestion(currentQuestionIndex + 1, questionSet);
                      } else {
                        const summary = Object.entries(updated)
                          .map(([key, val]) => `<li><strong>${key.replace(/_/g, " ")}:</strong> ${val}</li>`)
                          .join("");

                        const payload = {
                          id: Date.now(),
                          userName,
                          ...updated
                        };

                        const typeKey = propertyType.toLowerCase();
                        saveToServer(payload, typeKey);

                        botTypingThenSend(
                          `<div class="chatbot-summary-box"><p>✅ <strong>Summary:</strong></p><ul>${summary}</ul></div>`,
                          () => {
                            setStage("done");
                            setShowGenerate2D(true);
                          }
                        );
                      }
                    }}
                    style={{
                      padding: "10px 20px",
                      borderRadius: "6px",
                      backgroundColor: "#28a745",
                      color: "#fff",
                      border: "none",
                      cursor: "pointer"
                    }}
                  >
                    Submit
                  </button>
                </div>
              )}
            </div>
          )}

          {showGenerate2D && !imageBlob2D && (
            <div style={{ textAlign: "center", marginTop: "24px" }}>
              <button
                style={{
                  padding: "14px 30px",
                  backgroundColor: "#4CAF50",
                  color: "#fff",
                  fontSize: "16px",
                  border: "none",
                  borderRadius: "8px",
                  cursor: "pointer",
                  boxShadow: "0 4px 8px rgba(0,0,0,0.2)",
                  transition: "transform 0.2s ease"
                }}
                onClick={handleGenerate2D}
                onMouseEnter={(e) => (e.currentTarget.style.transform = "scale(1.05)")}
                onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
                disabled={loading}
              >
                {loading ? "🔄 Generating 2D Model..." : "🏗️ Generate 2D Model"}
              </button>
            </div>
          )}

          {showGenerate3D && (
            <div style={{ textAlign: "center", marginTop: "24px" }}>
              <button
                style={{
                  padding: "14px 30px",
                  backgroundColor: "#4CAF50",
                  color: "#fff",
                  fontSize: "16px",
                  border: "none",
                  borderRadius: "8px",
                  cursor: "pointer",
                  boxShadow: "0 4px 8px rgba(0,0,0,0.2)",
                  transition: "transform 0.2s ease"
                }}
                onClick={handleGenerate2D}
                onMouseEnter={(e) => (e.currentTarget.style.transform = "scale(1.05)")}
                onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
                disabled={loading}
              >
                {loading ? "🔄 Generating 2D Model..." : "🏗️ Generate 2D Model"}
              </button>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="chatbot-input-area">
          <input
            type="text"
            value={userInput}
            onChange={handleUserInput}
            placeholder="Type your response..."
            autoFocus
          />
          <button type="button" onClick={handleSubmit}>Send</button>
        </div>

      </div>
    </div >
  );
};

export default Chatbot;
