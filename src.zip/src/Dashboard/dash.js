import React, { useEffect, useState } from "react";
import "./dash.css";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const [filter, setFilter] = useState("villa");
  const [statusFilter, setStatusFilter] = useState("All");
  const [data, setData] = useState({ villa: [], building: [] });
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const villaRes = await fetch("http://localhost:3001/villa");
        const buildingRes = await fetch("http://localhost:3001/building");

        const villaData = await villaRes.json();
        const buildingData = await buildingRes.json();

        setData({ villa: villaData, building: buildingData });
      } catch (error) {
        console.error("Failed to fetch:", error);
      }
    };

    fetchData();
  }, []);

  const updateStatus = async (entryId, newStatus) => {
    try {
      const res = await fetch(`http://localhost:3001/${filter}/${entryId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (res.ok) {
        setData((prev) => {
          const updated = prev[filter].map((item) =>
            item.id === entryId ? { ...item, status: newStatus } : item
          );
          return { ...prev, [filter]: updated };
        });
      }
    } catch (error) {
      console.error("Failed to update status:", error);
    }
  };

  const filteredEntries = data[filter].filter((entry) => {
    if (statusFilter === "All") return true;
    if (statusFilter === "Pending") {
      return entry.status === "Not Started" || entry.status === "In Progress";
    }
    return entry.status === statusFilter;
  });

  const getColumnHeaders = () => {
    const sample = filteredEntries[0];
    if (!sample) return [];
    const headers = Object.keys(sample).filter((key) => key !== "id");
    if (!headers.includes("status")) headers.push("status");
    return headers;
  };

  return (
    <div className="dashboard-container">
      {/* Navbar */}
      <div className="dashboard-navbar">
        <button onClick={() => navigate(-1)} className="back-button">
          ← Back
        </button>
        <h2 className="dashboard-title">🏠 Progress Dashboard</h2>
      </div>

      {/* Filter Buttons */}
      <div className="dashboard-filters">
        <div className="type-filters">
          <button
            className={filter === "villa" ? "active" : ""}
            onClick={() => setFilter("villa")}
          >
            Villas
          </button>
          <button
            className={filter === "building" ? "active" : ""}
            onClick={() => setFilter("building")}
          >
            Buildings
          </button>
        </div>
        <div className="status-filters">
          <button
            className={statusFilter === "All" ? "active" : ""}
            onClick={() => setStatusFilter("All")}
          >
            All
          </button>
          <button
            className={statusFilter === "Pending" ? "active" : ""}
            onClick={() => setStatusFilter("Pending")}
          >
            Pending
          </button>
          <button
            className={statusFilter === "Completed" ? "active" : ""}
            onClick={() => setStatusFilter("Completed")}
          >
            Completed
          </button>
        </div>
      </div>

      {/* Table View */}
      <div className="dashboard-table-container">
        {filteredEntries.length === 0 ? (
          <p>No {filter} entries found.</p>
        ) : (
          <table className="dashboard-table">
            <thead>
              <tr>
                {getColumnHeaders().map((header) => (
                  <th key={header}>{header.replace(/_/g, " ")}</th>
                ))}
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredEntries.map((entry) => (
                <tr key={entry.id}>
                  {getColumnHeaders().map((key) => (
                    <td key={key}>
                      {key === "status" ? (
                        <select
                          value={entry.status}
                          onChange={(e) => updateStatus(entry.id, e.target.value)}
                        >
                          <option value="Not Started">Not Started</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Completed">Completed</option>
                        </select>
                      ) : (
                        entry[key]
                      )}
                    </td>
                  ))}
                  <td>
                    {entry.status === "Completed" ? (
                      <span className="status-completed">✅ Completed</span>
                    ) : (
                      <button
                        className="status-button"
                        onClick={() => updateStatus(entry.id, "Completed")}
                      >
                        Mark as Completed
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
