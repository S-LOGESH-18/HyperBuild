import React, { useRef } from "react";
import { Canvas, useThree, useFrame } from "@react-three/fiber";
import { OrbitControls, PerspectiveCamera, Html, Sky } from "@react-three/drei";
import * as THREE from "three";

// 🧱 Room with walls, floor, windows
const RoomBox = ({ position, size, color, label, onClick }) => {
  const wallThickness = 0.1;

  return (
    <group position={position} onClick={() => onClick(position)}>
      {/* Floor */}
      <mesh position={[0, -size[1] / 2, 0]} receiveShadow>
        <boxGeometry args={[size[0], wallThickness, size[2]]} />
        <meshStandardMaterial color="#ccc" />
      </mesh>

      {/* Ceiling */}
      <mesh position={[0, size[1] / 2, 0]}>
        <boxGeometry args={[size[0], wallThickness, size[2]]} />
        <meshStandardMaterial color="#ddd" />
      </mesh>

      {/* Walls */}
      {/* Front Wall */}
      <mesh position={[0, 0, size[2] / 2]} castShadow receiveShadow>
        <boxGeometry args={[size[0], size[1], wallThickness]} />
        <meshStandardMaterial color={color} />
      </mesh>
      {/* Back Wall */}
      <mesh position={[0, 0, -size[2] / 2]} castShadow receiveShadow>
        <boxGeometry args={[size[0], size[1], wallThickness]} />
        <meshStandardMaterial color={color} />
      </mesh>
      {/* Left Wall */}
      <mesh position={[-size[0] / 2, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[wallThickness, size[1], size[2]]} />
        <meshStandardMaterial color={color} />
      </mesh>
      {/* Right Wall */}
      <mesh position={[size[0] / 2, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[wallThickness, size[1], size[2]]} />
        <meshStandardMaterial color={color} />
      </mesh>

      {/* Door (Front center) */}
      <mesh position={[0, -size[1] / 2 + 1, size[2] / 2 + wallThickness / 2]}>
        <boxGeometry args={[1, 2, wallThickness]} />
        <meshStandardMaterial color="#8B4513" />
      </mesh>

      {/* Window (Right wall) */}
      <mesh position={[size[0] / 2 + 0.05, 0.5, 0]}>
        <boxGeometry args={[0.1, 1, 1]} />
        <meshStandardMaterial color="#87CEFA" transparent opacity={0.6} />
      </mesh>

      {/* Label */}
      <Html position={[0, size[1] / 2 + 0.5, 0]} center>
        <div style={{ color: "#000", fontWeight: "bold", fontSize: "12px", textAlign: "center" }}>{label}</div>
      </Html>
    </group>
  );
};

// 📷 Smooth camera transitions
const CameraAnimator = ({ targetPosition }) => {
  const { camera } = useThree();
  useFrame(() => {
    camera.position.lerp(targetPosition.current, 0.1);
    camera.lookAt(0, 0, 0);
  });
  return null;
};

// 🏠 Villa model generator
const VillaModelFromMetrics = ({ metrics }) => {
  const cameraTarget = useRef(new THREE.Vector3(25, 20, 25));
  const roomSize = [4, 3, 4];
  const floorYOffset = 5;

  const handleClick = (position) => {
    cameraTarget.current = new THREE.Vector3(...position).add(new THREE.Vector3(5, 5, 5));
  };

  const colors = {
    Bedroom: "#ffa07a",
    Puja: "#f0e68c",
    Media: "#9370db",
    Gym: "#90ee90",
    "Play Area": "#add8e6",
    Basement: "#778899",
    Parking: "#d2b48c",
    Lift: "#ffdead",
    Sump: "#4682b4",
    Generator: "#ffcc00",
    "Water Tank": "#d3d3d3"
  };

  const buildFloors = () => {
    const floors = [];

    for (let i = 0; i < metrics.villa_floors; i++) {
      const floor = [];

      if (i === 0) {
        if (metrics.villa_bedrooms) floor.push("Bedroom");
        if (metrics.villa_puja === "Yes") floor.push("Puja");
        if (metrics.villa_media === "Yes") floor.push("Media");
        if (metrics.villa_parking) floor.push("Parking");
        if (metrics.villa_lift === "Yes") floor.push("Lift");
        if (metrics.villa_sump === "Yes") floor.push("Sump");
        if (metrics.villa_generator === "Yes") floor.push("Generator");
        if (metrics.villa_basement === "Yes") floor.push("Basement");
      } else if (i === 1) {
        if (metrics.villa_gym === "Yes") floor.push("Gym");
        if (metrics.villa_play_area === "Yes") floor.push("Play Area");
      } else if (i === 2) {
        if (metrics.villa_water_storage) floor.push("Water Tank");
      }

      floors.push(floor);
    }

    return floors;
  };

  const floorData = buildFloors();
  const rooms = [];

  floorData.forEach((floorRooms, floorIndex) => {
    floorRooms.forEach((room, index) => {
      const x = index * (roomSize[0] + 1);
      const y = floorIndex * floorYOffset;
      const z = 0;

      rooms.push(
        <RoomBox
          key={`${room}-${floorIndex}`}
          position={[x, y, z]}
          size={roomSize}
          color={colors[room] || "#ccc"}
          label={room}
          onClick={handleClick}
        />
      );
    });
  });

  // 🌱 Grass base ground
  rooms.push(
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[20, -1.5, 10]} receiveShadow key="ground">
      <planeGeometry args={[100, 100]} />
      <meshStandardMaterial color="#7CFC00" />
    </mesh>
  );

  // ⛅ Sky background
  rooms.push(<Sky key="sky" sunPosition={[100, 20, 100]} />);

  // 🧱 Outer fencing around plot
  const fenceHeight = 2;
  const fenceLength = 40;
  const fenceWidth = 30;

  const fenceMaterial = <meshStandardMaterial color="#8B8B8B" />;
  const fenceGeo = <boxGeometry args={[0.5, fenceHeight, fenceWidth]} />;

  rooms.push(
    <mesh position={[0, fenceHeight / 2 - 1, -fenceWidth / 2]}>{fenceGeo}{fenceMaterial}</mesh>
  );
  rooms.push(
    <mesh position={[0, fenceHeight / 2 - 1, fenceWidth / 2]}>{fenceGeo}{fenceMaterial}</mesh>
  );
  rooms.push(
    <mesh position={[-fenceLength / 2, fenceHeight / 2 - 1, 0]} rotation={[0, Math.PI / 2, 0]}>
      <boxGeometry args={[0.5, fenceHeight, fenceLength]} />
      <meshStandardMaterial color="#8B8B8B" />
    </mesh>
  );
  rooms.push(
    <mesh position={[fenceLength / 2, fenceHeight / 2 - 1, 0]} rotation={[0, Math.PI / 2, 0]}>
      <boxGeometry args={[0.5, fenceHeight, fenceLength]} />
      <meshStandardMaterial color="#8B8B8B" />
    </mesh>
  );

  return (
    <div style={{ width: "100vw", height: "100vh" }}>
      <Canvas shadows camera={{ position: [25, 20, 25], fov: 60 }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[30, 50, 30]} intensity={1} castShadow />
        <PerspectiveCamera makeDefault position={[25, 20, 25]} />
        <OrbitControls />
        <CameraAnimator targetPosition={cameraTarget} />
        <group>{rooms}</group>
      </Canvas>
    </div>
  );
};

export default VillaModelFromMetrics;
