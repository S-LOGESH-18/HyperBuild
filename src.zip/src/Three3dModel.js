import React from 'react';
import { Canvas } from '@react-three/fiber';
import Scene from './Models/Villa';
import './App.css';

const ThreeDModel = () => {
  return (
    <div className="canvas-wrapper">
      <Canvas shadows camera={{ position: [10, 10, 20], fov: 50 }}>
        <Scene />
      </Canvas>
    </div>
  );
};

export default ThreeDModel;
