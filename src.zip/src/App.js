import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Chatbot from './Chatbot/Chatbot';
import './App.css';
import Dashboard from './Dashboard/dash';
import Viewer from './Models/Viewer';
import 'react-toastify/dist/ReactToastify.css';

const App = () => {
  return (
    <div>
    <Router>
      <Routes>
        <Route path="/" element={<Chatbot />} />
        <Route path="/viewer" element={<Viewer/>} />
        <Route path="/dashboard" element={<Dashboard/>} />
      </Routes>
    </Router>
    </div>
  );
};

export default App;
